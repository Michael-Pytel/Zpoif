package pl.edu.pw.mini.zpoif.punktowane.pudelko.akcesoria;

public abstract class Kaloryczne extends Akcesoria {

	protected int kalorycznosc;

	public int getKalorycznosc() {
		return kalorycznosc;
	}



}
